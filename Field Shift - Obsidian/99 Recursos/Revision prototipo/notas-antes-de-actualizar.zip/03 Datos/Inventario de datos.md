---
tipo: inventario
estado: sin-descargas-locales
---
# Inventario de datos

**Disponible hoy:** dos textos de conversaciones y documentación consultada. **No disponible todavía:** archivos NASA del lote, registros de suelo, rindes de campo, entrevistas, prototipo o ZIP.

| Fuente propuesta | Uso | Prioridad | Estado |
| --- | --- | --- | --- |
| NASA POWER | Contexto climático histórico | Base | Documentación revisada; consulta pendiente |
| SMAP L4 o L3, según variable | Humedad regional | Segunda integración | Elegir producto y extraer |
| Información local de suelo | Restricciones y almacenamiento | Necesaria para balance | Falta conseguir |
| Calendarios y parámetros de cultivos | Definir secuencias | Necesarios | Falta fuente local |
| GPM IMERG | Episodio o distribución histórica de lluvia | Según caso | Sin descarga |
| HLS | Vegetación y contexto espacial | Opcional | Sin escenas del lote |
| ECOSTRESS | ET/estrés en fechas con calidad | Opcional | Sin extracción |
| MAGyP | Producción y rendimiento departamental | Contexto | Sin CSV |
| GIBS | Visualización cartográfica | Opcional | No reemplaza datos numéricos |
| SoilGrids | Propiedades estimadas del suelo | Respaldo | No sustituye análisis de campo |

## Endpoints recibidos

Conservar los ejemplos de POWER, GIBS, CMR y AppEEARS en [[Claude - original]]. Son puntos de partida; **no fueron ejecutados en este trabajo**. Ajustar punto, rango, producto y parámetros con la documentación vigente.

Para cada descarga, crear una [[Ficha de fuente]] y guardar el original sin cambios junto a metadatos. Anotar identificación del producto, versión, fechas y método de extracción. Los tokens y contraseñas van fuera de la bóveda.

## Arquitectura propuesta para cuando se implemente

Datos numéricos → controles de calidad y unidades → archivo de evidencia → motor de reglas → interfaz de comparación.

Vite/TypeScript, Leaflet y gráficos son elecciones sugeridas por Claude, aún no adoptadas. AppEEARS es asíncrono: preparar archivos de demo con anticipación. Evaluar la necesidad real de backend al revisar autenticación, CORS y el servicio elegido.
