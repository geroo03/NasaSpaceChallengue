---
tipo: caso
estado: por-completar
ubicacion: Añatuya, Santiago del Estero, Argentina
---
# Caso Añatuya

Caso inicial propuesto. No se cuenta aún con un productor identificado ni un polígono real.

## Ficha del lote

| Campo | Valor |
| --- | --- |
| Productor o identificador | Pendiente |
| Tipo de caso | Pendiente: real con permiso / ilustrativo |
| Latitud, longitud y polígono | Pendiente; no usar el punto de ejemplo como ubicación confirmada |
| Superficie | Pendiente |
| Secano o riego | Secano como supuesto inicial a confirmar |
| Textura y análisis de suelo | Pendiente |
| Profundidad útil / raíces | Pendiente |
| Manejo y rotación actual | Pendiente |
| Prioridad | Agua o cobertura, a confirmar con el productor |
| Maquinaria, mercado y semillas | Pendiente |
| Campañas de comparación | Pendiente según disponibilidad de datos |

## Cuatro estrategias

| ID | Estrategia | Estado |
| --- | --- | --- |
| R0 | Rotación actual del productor | Falta entrevista |
| R1 | Alternativa que incorpore una leguminosa | Candidata a definir localmente |
| R2 | Alternativa con sorgo para el objetivo productivo elegido | Candidata a definir localmente |
| R3 | Alternativa de manejo de cobertura entre cultivos | Candidata a definir; revisar consumo de agua |

Los materiales mencionan sorgo/caupí y soja/maíz. No hay evidencia adjunta que permita elegir una secuencia definitiva para este lote. Caupí puede ser una candidata, sujeta a ciclo, destino, semillas y manejo local. Las cuatro opciones finales deben ser distintas y viables en el mismo horizonte.

**Rotación:** sucesión de cultivos en el tiempo. **Intercultivo:** cultivos simultáneos. Registrar esa diferencia en cada calendario.

## Evidencia mínima del caso

- [ ] Ubicación confirmada y origen del dato.
- [ ] Rotación actual documentada o declarada ilustrativa.
- [ ] Prioridad expresada por el productor o supuesto explícito.
- [ ] Serie histórica, controles de calidad y período de referencia.
- [ ] Parámetros agronómicos trazables para cada secuencia.
- [ ] Comparación reproducible con riesgos y vacíos visibles.

Usar [[Entrevista de campo]] para conseguir los datos locales.
