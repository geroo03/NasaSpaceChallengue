---
tipo: presentacion
estado: borrador-conceptual
---
# Pitch y guion

## Pitch para el estado actual

Field Shift es una propuesta para ayudar a productores de Añatuya a comparar rotaciones cuando el agua limita sus decisiones. Planteamos combinar información NASA sobre clima y humedad regional con datos del suelo, cultivos y prioridades del productor. La demo prevista comparará el manejo actual con tres alternativas y explicará qué evidencia favorece cada opción, qué riesgos tiene y qué información falta. El siguiente paso es construir una comparación reproducible para un caso local y revisarla con conocimiento agronómico de la zona.

Cuando exista una demo, reemplazar el futuro por funciones efectivamente verificadas y nombrar los productos realmente utilizados. No presentar integraciones previstas como realizadas.

## Recorrido narrativo

| Momento | Qué mostrar |
| --- | --- |
| Problema | Una decisión concreta del productor y las restricciones del caso |
| Entrada | Lote, rotación actual, suelo y prioridad |
| Evidencia | Un indicador NASA con valor, fecha, unidad y escala |
| Comparación | Actual + tres alternativas sobre el mismo calendario |
| Explicación | Por qué una opción cambia al modificar la prioridad |
| Cierre | Riesgos, vacíos y plan de validación |

Adaptar la duración a la guía confirmada para la sede. Los 2–3 minutos del material de Claude son una propuesta de guion, no una regla verificada aquí.

## Respuestas al jurado

**¿Cuánta agua ahorra?** Todavía no lo medimos. El piloto definirá indicadores según sea secano o riego y comparará manejos bajo condiciones documentadas.

**¿El satélite mide este lote?** Depende del producto. La interfaz mostrará la escala y si el valor es una recuperación satelital, una estimación modelada o una medición de campo.

**¿La recomendación está validada?** El estado de cada opción debe estar visible. La demo explora alternativas; no debe atribuirse validación de campo sin registros.

**¿Qué hace la IA?** Declarar el uso real: investigación asistida, organización de documentación, código o redacción. Si no se integra un LLM al producto, no presentarlo como funcionalidad.

**¿Qué falta?** Ubicación y manejo actual, datos locales, parámetros de cultivo y una revisión reproducible. Actualizar esta respuesta antes de presentar.

Revisar [[Matriz de evidencia]] antes de incluir porcentajes o testimonios.
