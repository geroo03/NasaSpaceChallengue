---
tipo: inicio
actualizado: 2026-11-14
tags: [field-shift, space-apps]
---
# Field Shift — espacio de trabajo

**Dirección propuesta:** ayudar a un productor de Añatuya a comparar su rotación actual con tres alternativas durante dos años, según el agua disponible, el suelo y sus prioridades. Cada opción debe explicar la evidencia, los beneficios esperados, los riesgos y los datos faltantes.

Esta carpeta organiza las dos conversaciones recibidas. Todavía no contiene un prototipo, descargas satelitales ni resultados locales comprobados. Las decisiones que siguen son propuestas de trabajo.

## Empezá por acá

1. [[A dónde apuntamos]] — la recomendación y cómo se complementan Claude y GPT.
2. [[MVP y demo]] — qué construir y cómo saber que está listo.
3. [[Plan de trabajo]] — tareas ordenadas para el 14–15 de noviembre.
4. [[Caso Añatuya]] — los datos concretos que falta conseguir.

## Mapa de notas

| Tema | Notas |
| --- | --- |
| Dirección | [[A dónde apuntamos]] · [[MVP y demo]] · [[Decisiones]] |
| Investigación | [[Fuentes verificadas]] · [[Matriz de evidencia]] · [[Correcciones técnicas]] |
| Datos | [[Inventario de datos]] · [[Caso Añatuya]] · [[Protocolo reproducible]] |
| Entrega | [[Pitch y guion]] · [[Plan de trabajo]] |
| Material recibido | [[Claude - original]] · [[GPT - original]] |
| Plantillas | [[Ficha de fuente]] · [[Entrevista de campo]] |

## Estado de la evidencia

- **Recibido:** afirmación presente en un texto del usuario; conservar su atribución.
- **Verificado documentalmente:** respaldado por una fuente primaria consultada; no significa implementado.
- **Propuesto:** elección de alcance o método para el proyecto.
- **Pendiente:** falta documento, descarga, ejecución o validación local.
- **Medido:** reservar para resultados con archivos y método reproducible. Hoy no hay resultados en esta categoría.

## Abrir esta carpeta

En Obsidian, elegí **Abrir carpeta como bóveda** y seleccioná `Field Shift - Obsidian`. Abrí esta nota. Los enlaces `[[...]]`, las tareas y el diagrama funcionan con las funciones integradas; no hace falta instalar extensiones.

Guardá imágenes y documentos en `99 Recursos/Adjuntos`. Para una nueva fuente o entrevista, duplicá una nota de `90 Plantillas`.
