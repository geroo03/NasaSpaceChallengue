---
tipo: estrategia
estado: propuesto
fecha: 2026-11-14
---
# A dónde apuntamos

**Apuntamos a una decisión concreta: qué rotación conviene explorar para este lote y por qué.** El caso inicial propuesto es un productor de secano de Añatuya, Santiago del Estero. Si no conseguimos un lote real, la demo debe presentarlo como caso ilustrativo de la zona.

## Cómo juntar lo que ya tenemos

| Material | Qué aporta | Cómo usarlo |
| --- | --- | --- |
| [[Claude - original]] | APIs, arquitectura, flujo del productor y cuatro estrategias | Base para planificar el producto; sus pruebas y reglas se deben reproducir |
| [[GPT - original]] | Auditoría de escalas, porcentajes e impacto | Criterios para revisar cada afirmación y diseñar la validación |

La auditoría de GPT sugería dos secuencias como primer ensayo reproducible. El material de Claude propone una comparación más amplia. Para el producto tomamos **actual + tres alternativas**; podemos validar primero un par sin presentar ese ensayo parcial como la demo completa.

## Propuesta de valor

> Convertimos información de clima, suelo y cultivos en una comparación explicable de rotaciones para el productor. Mostramos qué cambia con sus prioridades y qué falta comprobar en el lote.

## Alcance recomendado

- Un lote y un perfil de productor.
- Un horizonte común de 24 meses para todas las opciones.
- Cuatro secuencias: la actual y tres candidatas revisadas localmente.
- Prioridades iniciales: agua y cobertura del suelo. Ingresos, maquinaria y mercado entran como restricciones declaradas; sin costos y precios no calculamos rentabilidad.
- Base climática NASA POWER y una extracción válida de SMAP como contexto regional. Incorporar IMERG para estudiar lluvia si hay tiempo y descarga trazable.
- ECOSTRESS y HLS se agregan cuando aporten evidencia útil al caso y tengamos escenas de calidad.

## Qué demostrar

Una misma parcela puede llevar a distintas preferencias de rotación según las restricciones del productor y el escenario explorado. El motor debe explicar el cambio con reglas visibles y datos trazables. Eso es una hipótesis de producto a demostrar, no un resultado ya obtenido.

Los escenarios de −20 % de lluvia o +2 °C, si se usan, son perturbaciones elegidas por el usuario sobre una serie base. No son pronósticos ni proyecciones climáticas validadas.

## Próxima acción concreta

Completar [[Caso Añatuya]], conseguir una serie climática y definir las cuatro secuencias con un referente local. Después construir [[MVP y demo]]. Registrar cada cambio de alcance en [[Decisiones]].
