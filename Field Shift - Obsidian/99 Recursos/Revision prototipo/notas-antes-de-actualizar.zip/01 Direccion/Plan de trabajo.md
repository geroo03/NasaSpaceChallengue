---
tipo: tareas
fecha: 2026-11-14
estado: propuesto
---
# Plan de trabajo

Plan actualizado al sábado **14 de noviembre de 2026**, hora de Córdoba, Argentina. El cronograma recibido menciona cierre el domingo 15 a las 23:59; falta confirmar sede, zona horaria y formato en la guía aplicable al equipo. No extrapolar horarios de otras sedes.

## 1. Definir el caso

- [ ] Completar [[Caso Añatuya]]: ubicación, productor o carácter ilustrativo, suelo y manejo actual.
- [ ] Elegir cuatro secuencias con disponibilidad local de cultivos y maquinaria.
- [ ] Confirmar sede, enlace del equipo, requisitos de entrega y duración del video.
- [ ] Localizar `field-shift.zip`, mencionado por Claude: no fue adjuntado y la carpeta del proyecto estaba vacía al iniciar este trabajo.
- [ ] Si se recupera código previo, revisar sus condiciones de uso y las reglas de la edición antes de incorporarlo a la entrega.

## 2. Conseguir evidencia

- [ ] Descargar POWER para el punto correcto; guardar respuesta y metadatos.
- [ ] Solicitar SMAP mediante el servicio disponible; guardar datos y calidad.
- [ ] Registrar unidades y faltantes según [[Protocolo reproducible]].
- [ ] Conseguir parámetros de suelo/cultivo y su fuente; marcar los supuestos.
- [ ] Decidir si IMERG aporta al episodio elegido antes de sumar otra integración.

## 3. Construir la comparación

- [ ] Crear formulario de lote y prioridades.
- [ ] Implementar cuatro calendarios sobre el mismo período.
- [ ] Implementar reglas y explicación con trazabilidad de cada indicador.
- [ ] Mostrar razones, evidencia, beneficios, vacíos y riesgos por opción.
- [ ] Guardar el caso de demo para usarlo sin conexión.

## 4. Revisar y entregar

- [ ] Comprobar unidades, fechas, faltantes y coordenadas.
- [ ] Revisar una comparación con productor o agrónomo, si está disponible.
- [ ] Ensayar el recorrido completo con datos guardados.
- [ ] Ajustar [[Pitch y guion]] a lo efectivamente construido.
- [ ] Documentar uso real de IA, fuentes, limitaciones y origen del código.
- [ ] Verificar enlaces de entrega y guardar comprobante de envío.

## Si queda tiempo

- [ ] HLS para contexto de vegetación con máscara de calidad.
- [ ] ECOSTRESS para una escena útil y bien interpretada.
- [ ] Escenario de sensibilidad con lluvia y temperatura.
- [ ] Glosario en la interfaz.
- [ ] LLM para redactar el JSON de evidencia, solo si mejora una explicación ya funcional con plantillas.

**Orden de recorte:** sacar primero LLM, lote extranjero y capas extra. Conservar comparación, evidencia y funcionamiento de la demo.
