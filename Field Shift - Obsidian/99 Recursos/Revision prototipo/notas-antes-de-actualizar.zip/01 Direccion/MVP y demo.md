---
tipo: especificacion
estado: propuesto
---
# MVP y demo

## Recorrido del productor

1. Selecciona el lote y confirma si la ubicación es real o ilustrativa.
2. Carga rotación actual, secano o riego, información de suelo y restricciones conocidas. Lo desconocido queda visible como desconocido.
3. Elige la prioridad principal: agua o cobertura.
4. Compara **actual + tres alternativas**, con calendarios sobre el mismo horizonte de dos años.
5. Abre una opción y encuentra razones, evidencia, beneficios potenciales, riesgos y datos faltantes.
6. Cambia una prioridad o un escenario y ve qué resultado cambia y qué regla lo explica.

## Contrato de cada tarjeta

| Campo | Contenido |
| --- | --- |
| Secuencia | Cultivo y manejo por período; fechas y duración documentadas |
| Razón | Regla que favorece o limita esa secuencia |
| Evidencia | Valor, unidad, período, fuente y escala espacial |
| Beneficio potencial | Hipótesis agronómica con referencia; sin ahorro garantizado |
| Riesgo | Restricción del caso y revisión local necesaria |
| Vacío | Dato faltante y cómo condiciona la comparación |
| Estado | Exploración, pendiente de revisión o revisado localmente |

## Motor mínimo

Primero revisar restricciones. Después comparar indicadores con reglas documentadas. Si usamos puntajes, publicar fórmula, pesos y origen de parámetros: un puntaje de preferencia no es una probabilidad de éxito.

No usar como exclusiones automáticas los umbrales de helada del 50 % o déficit del 75 % del texto de Claude hasta definir cálculo y validación. Si falta un dato decisivo, mostrar comparación incompleta en lugar de completar con un número inventado.

El calendario permite señalar meses sin cultivo vivo, pero eso no prueba suelo desnudo: puede haber rastrojo o cobertura no registrada.

```mermaid
flowchart TD
    A[Lote y prioridades] --> D[Comparación con reglas visibles]
    B[Datos NASA y calidad] --> D
    C[Suelo y parámetros de cultivos] --> D
    D --> E[Rotación actual y tres alternativas]
    E --> F[Evidencia, riesgos y vacíos]
    F --> G[Revisión con productor o agrónomo]
```

## Listo para mostrar cuando

- [ ] Las cuatro estrategias corresponden al mismo lote y período.
- [ ] La rotación actual viene de una entrevista o está etiquetada como ilustrativa.
- [ ] Al menos una fuente NASA numérica tiene un archivo descargado y trazable; la segunda fuente tiene estado explícito.
- [ ] El motor explica qué cambió al modificar una prioridad.
- [ ] Un valor faltante no se interpreta como cero.
- [ ] La demo funciona con datos guardados y muestra su fecha.
- [ ] El pitch describe exactamente lo que funciona.

El producto sigue siendo un prototipo exploratorio si faltan validación agronómica o datos locales.
