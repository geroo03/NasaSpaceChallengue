declare module 'shpjs' {
  import type { FeatureCollection } from 'geojson';
  /** Parses a zipped shapefile (reprojected to WGS84 via its .prj). One FeatureCollection per .shp. */
  export default function shp(input: ArrayBuffer | Uint8Array | string): Promise<FeatureCollection | FeatureCollection[]>;
}
