// @vitest-environment jsdom
import { describe, expect, it } from 'vitest';
import JSZip from 'jszip';
import proj4 from 'proj4';
import type { Polygon } from 'geojson';
import { aCandidatos, medir, validar } from '../lote/geometria';
import { conversorAWgs84, decidirEjes, fajaPorEste } from '../lote/crs';
import { ErrorImportacion, importarArchivo, type ResultadoImportacion } from '../lote/importar';
import { mejorPasada, parsearPasadas, urlTeselaHls } from '../lote/hls';

// A ~500 m × 400 m field near Santiago del Estero, as lon/lat corners (counter-clockwise).
const LAT0 = -27.78;
const LON0 = -64.26;
const dLat = 400 / 111_320;
const dLon = 500 / (111_320 * Math.cos((LAT0 * Math.PI) / 180));
const ESQUINAS: [number, number][] = [
  [LON0, LAT0],
  [LON0 + dLon, LAT0],
  [LON0 + dLon, LAT0 + dLat],
  [LON0, LAT0 + dLat],
];
const anillo = (pts: [number, number][]) => [...pts, pts[0]!];

const POSGAR4 = '+proj=tmerc +lat_0=-90 +lon_0=-63 +k=1 +x_0=4500000 +y_0=0 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs';
const aPosgar4 = (lonlat: [number, number]) => proj4('WGS84', POSGAR4, lonlat) as [number, number];

const opciones = { crsDxf: 'posgar2007-4' as const, crearUrl: () => 'blob:prueba' };

function parcelas(r: ResultadoImportacion) {
  if (r.tipo !== 'parcelas') throw new Error('se esperaban parcelas');
  return r;
}

function esperarCercaDelLote(geometry: Polygon) {
  const m = medir(geometry);
  expect(m.areaHa).toBeGreaterThan(19);
  expect(m.areaHa).toBeLessThan(21);
  expect(Math.abs(m.centroLat - (LAT0 + dLat / 2))).toBeLessThan(1e-5);
  expect(Math.abs(m.centroLon - (LON0 + dLon / 2))).toBeLessThan(1e-5);
}

describe('geometría del lote', () => {
  it('mide ≈ 20 ha y valida un lote normal', () => {
    const g: Polygon = { type: 'Polygon', coordinates: [anillo(ESQUINAS)] };
    expect(validar(g)).toBeNull();
    esperarCercaDelLote(g);
  });

  it('rechaza polígonos que se cruzan, chicos, enormes y con pocas esquinas', () => {
    const [a, b, c, d] = ESQUINAS;
    expect(validar({ type: 'Polygon', coordinates: [anillo([a!, c!, b!, d!])] })).toBe('seCruza');
    const chico: [number, number][] = [[LON0, LAT0], [LON0 + 0.0003, LAT0], [LON0 + 0.0003, LAT0 + 0.0003], [LON0, LAT0 + 0.0003]];
    expect(validar({ type: 'Polygon', coordinates: [anillo(chico)] })).toBe('muyChico');
    const enorme: [number, number][] = [[LON0, LAT0], [LON0 + 1, LAT0], [LON0 + 1, LAT0 + 1], [LON0, LAT0 + 1]];
    expect(validar({ type: 'Polygon', coordinates: [anillo(enorme)] })).toBe('muyGrande');
    expect(validar({ type: 'Polygon', coordinates: [[a!, b!, a!]] })).toBe('pocosVertices');
  });

  it('bloquea multipolígonos de varias partes y convierte líneas cerradas', () => {
    const otro = ESQUINAS.map(([x, y]) => [x + 0.02, y] as [number, number]);
    const c = aCandidatos(
      [
        { type: 'Feature', properties: { name: 'Doble' }, geometry: { type: 'MultiPolygon', coordinates: [[anillo(ESQUINAS)], [anillo(otro)]] } },
        { type: 'Feature', properties: { NOMBRE: 'Contorno' }, geometry: { type: 'LineString', coordinates: anillo(ESQUINAS) } },
      ],
      't',
    );
    expect(c.map((x) => x.motivo)).toEqual(['variasPartes', 'variasPartes', null]);
    expect(c[2]!.nombre).toBe('Contorno');
  });
});

describe('sistemas de coordenadas POSGAR 2007', () => {
  it('convierte la faja 4 ida y vuelta con error submétrico', () => {
    const p = aPosgar4([LON0, LAT0]);
    expect(fajaPorEste(p[0])).toBe(4);
    const [lon, lat] = conversorAWgs84('posgar2007-4')(p);
    expect(Math.abs(lon - LON0)).toBeLessThan(1e-7);
    expect(Math.abs(lat - LAT0)).toBeLessThan(1e-7);
  });

  it('detecta ejes invertidos y la faja real', () => {
    const [e, n] = aPosgar4([LON0, LAT0]);
    expect(decidirEjes(e, n, 4)).toEqual({ invertir: false, fajaDetectada: 4 });
    expect(decidirEjes(n, e, 4)).toEqual({ invertir: true, fajaDetectada: 4 });
    expect(decidirEjes(e, n, 5).fajaDetectada).toBe(4);
  });
});

describe('importación de archivos', () => {
  const coordsKml = (pts: [number, number][]) => anillo(pts).map(([x, y]) => `${x},${y},0`).join(' ');
  const chico: [number, number][] = [[LON0, LAT0], [LON0 + 0.0003, LAT0], [LON0 + 0.0003, LAT0 + 0.0003], [LON0, LAT0 + 0.0003]];
  const KML = `<?xml version="1.0"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document>
    <Placemark><name>Lote Norte</name><Polygon><outerBoundaryIs><LinearRing><coordinates>${coordsKml(ESQUINAS)}</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>
    <Placemark><name>Galpón</name><Polygon><outerBoundaryIs><LinearRing><coordinates>${coordsKml(chico)}</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>
  </Document></kml>`;

  it('KML: lista las parcelas con nombre y bloquea las inválidas', async () => {
    const r = parcelas(await importarArchivo(new File([KML], 'catastro.kml'), opciones));
    expect(r.candidatos.map((c) => [c.nombre, c.motivo])).toEqual([
      ['Lote Norte', null],
      ['Galpón', 'muyChico'],
    ]);
    esperarCercaDelLote(r.candidatos[0]!.geometry);
  });

  it('KMZ: lee el doc.kml de adentro', async () => {
    const zip = new JSZip();
    zip.file('doc.kml', KML);
    const buf = await zip.generateAsync({ type: 'arraybuffer' });
    const r = parcelas(await importarArchivo(new File([buf], 'campo.kmz'), opciones));
    expect(r.candidatos).toHaveLength(2);
  });

  it('GeoJSON: acepta lat/lon y rechaza metros con un mensaje útil', async () => {
    const fc = { type: 'FeatureCollection', features: [{ type: 'Feature', properties: { lote: 'L1' }, geometry: { type: 'Polygon', coordinates: [anillo(ESQUINAS)] } }] };
    const r = parcelas(await importarArchivo(new File([JSON.stringify(fc)], 'lote.geojson'), opciones));
    expect(r.candidatos[0]!.nombre).toBe('L1');
    const enMetros = { type: 'Polygon', coordinates: [anillo(ESQUINAS.map(aPosgar4))] };
    await expect(importarArchivo(new File([JSON.stringify(enMetros)], 'm.geojson'), opciones)).rejects.toMatchObject({ clave: 'import.error.noLonLat' });
  });

  it('Shapefile .zip: reproyecta desde POSGAR 2007 faja 4 usando el .prj', async () => {
    const zip = new JSZip();
    const { shp, shx, dbf } = shapefilePoligono(anillo(ESQUINAS.map(aPosgar4)), 'Parcela 12');
    zip.file('lotes.shp', shp);
    zip.file('lotes.shx', shx);
    zip.file('lotes.dbf', dbf);
    zip.file('lotes.prj', PRJ_POSGAR4);
    const buf = await zip.generateAsync({ type: 'arraybuffer' });
    const r = parcelas(await importarArchivo(new File([buf], 'catastro.zip'), opciones));
    expect(r.candidatos[0]!.nombre).toBe('Parcela 12');
    esperarCercaDelLote(r.candidatos[0]!.geometry);
  });

  it('Shapefile sin .prj: lo rechaza en vez de adivinar', async () => {
    const zip = new JSZip();
    const { shp, shx } = shapefilePoligono(anillo(ESQUINAS.map(aPosgar4)), 'x');
    zip.file('a.shp', shp);
    zip.file('a.shx', shx);
    const buf = await zip.generateAsync({ type: 'arraybuffer' });
    await expect(importarArchivo(new File([buf], 'a.zip'), opciones)).rejects.toBeInstanceOf(ErrorImportacion);
  });

  it('DXF en POSGAR faja 4: ubica el lote; corrige ejes invertidos y faja equivocada', async () => {
    const pts = ESQUINAS.map(aPosgar4);
    const normal = parcelas(await importarArchivo(new File([dxf(pts)], 'mensura.dxf'), opciones));
    expect(normal.candidatos[0]!.nombre).toBe('LOTE_A 1');
    esperarCercaDelLote(normal.candidatos[0]!.geometry);

    const invertido = parcelas(await importarArchivo(new File([dxf(pts.map(([e, n]) => [n, e]))], 'mensura.dxf'), opciones));
    expect(invertido.avisos.map((a) => a.clave)).toContain('import.aviso.ejesInvertidos');
    esperarCercaDelLote(invertido.candidatos[0]!.geometry);

    const fajaMal = parcelas(await importarArchivo(new File([dxf(pts)], 'mensura.dxf'), { ...opciones, crsDxf: 'posgar2007-5' }));
    expect(fajaMal.avisos.map((a) => a.clave)).toContain('import.aviso.fajaCorregida');
    esperarCercaDelLote(fajaMal.candidatos[0]!.geometry);
  });

  it('PDF o foto: se adjunta como guía, sin coordenadas', async () => {
    const r = await importarArchivo(new File(['%PDF-1.4'], 'plano.pdf', { type: 'application/pdf' }), opciones);
    expect(r).toMatchObject({ tipo: 'guia', archivo: 'plano.pdf', url: 'blob:prueba' });
  });

  it('formato desconocido: error claro', async () => {
    await expect(importarArchivo(new File(['x'], 'plano.dwg'), opciones)).rejects.toMatchObject({ clave: 'import.error.formato' });
  });
});

describe('NASA HLS', () => {
  it('ordena las pasadas, quita duplicados y elige la más reciente con pocas nubes', () => {
    const p = parsearPasadas({
      features: [
        { collection: 'HLSS30_2.0', properties: { datetime: '2026-09-15T14:30:39Z', 'eo:cloud_cover': 0 } },
        { collection: 'HLSL30_2.0', properties: { datetime: '2026-11-05T14:13:41Z', 'eo:cloud_cover': 51 } },
        { collection: 'HLSS30_2.0', properties: { datetime: '2026-09-23T14:30:26Z', 'eo:cloud_cover': 0 } },
        { collection: 'HLSS30_2.0', properties: { datetime: '2026-09-23T14:30:40Z', 'eo:cloud_cover': 3 } },
      ],
    });
    expect(p.map((x) => `${x.fecha}-${x.sensor}`)).toEqual(['2026-11-05-L30', '2026-09-23-S30', '2026-09-15-S30']);
    const m = mejorPasada(p)!;
    expect(m.fecha).toBe('2026-09-23');
    expect(urlTeselaHls(m)).toContain('HLS_S30_Nadir_BRDF_Adjusted_Reflectance/default/2026-09-23/GoogleMapsCompatible_Level12');
  });
});

// ---------------------------------------------------------------------------
// Minimal file builders (so the tests need no fixtures on disk)
// ---------------------------------------------------------------------------

const PRJ_POSGAR4 =
  'PROJCS["POSGAR 2007 / Argentina 4",GEOGCS["POSGAR 2007",DATUM["Posiciones_Geodesicas_Argentinas_2007",SPHEROID["GRS 1980",6378137,298.257222101],TOWGS84[0,0,0,0,0,0,0]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",-90],PARAMETER["central_meridian",-63],PARAMETER["scale_factor",1],PARAMETER["false_easting",4500000],PARAMETER["false_northing",0],UNIT["metre",1]]';

function dxf(pts: number[][]): string {
  const lineas = ['0', 'SECTION', '2', 'ENTITIES', '0', 'LWPOLYLINE', '8', 'LOTE_A', '90', String(pts.length), '70', '1'];
  for (const [x, y] of pts) lineas.push('10', String(x), '20', String(y));
  lineas.push('0', 'ENDSEC', '0', 'EOF');
  return lineas.join('\n');
}

/** ESRI Shapefile, one polygon record (shape type 5), plus .shx and a one-field .dbf. */
function shapefilePoligono(ring: number[][], nombre: string) {
  const xs = ring.map((p) => p[0]!);
  const ys = ring.map((p) => p[1]!);
  const bbox = [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
  const contenido = 4 + 32 + 4 + 4 + 4 + ring.length * 16;
  const shpLen = 100 + 8 + contenido;

  const header = (v: DataView, largoBytes: number) => {
    v.setInt32(0, 9994, false);
    v.setInt32(24, largoBytes / 2, false);
    v.setInt32(28, 1000, true);
    v.setInt32(32, 5, true);
    bbox.forEach((b, i) => v.setFloat64(36 + i * 8, b, true));
  };

  const shp = new ArrayBuffer(shpLen);
  const s = new DataView(shp);
  header(s, shpLen);
  s.setInt32(100, 1, false);
  s.setInt32(104, contenido / 2, false);
  let o = 108;
  s.setInt32(o, 5, true);
  o += 4;
  bbox.forEach((b, i) => s.setFloat64(o + i * 8, b, true));
  o += 32;
  s.setInt32(o, 1, true);
  s.setInt32(o + 4, ring.length, true);
  s.setInt32(o + 8, 0, true);
  o += 12;
  for (const [x, y] of ring) {
    s.setFloat64(o, x!, true);
    s.setFloat64(o + 8, y!, true);
    o += 16;
  }

  const shx = new ArrayBuffer(108);
  const x = new DataView(shx);
  header(x, 108);
  x.setInt32(100, 50, false);
  x.setInt32(104, contenido / 2, false);

  const campo = 40;
  const headerLen = 32 + 32 + 1;
  const dbf = new Uint8Array(headerLen + 1 + campo + 1);
  const d = new DataView(dbf.buffer);
  dbf[0] = 0x03;
  d.setUint32(4, 1, true);
  d.setUint16(8, headerLen, true);
  d.setUint16(10, 1 + campo, true);
  dbf.set(new TextEncoder().encode('NOMBRE'), 32);
  dbf[32 + 11] = 'C'.charCodeAt(0);
  dbf[32 + 16] = campo;
  dbf[64] = 0x0d;
  dbf[headerLen] = 0x20;
  dbf.set(new TextEncoder().encode(nombre.padEnd(campo, ' ')), headerLen + 1);
  dbf[dbf.length - 1] = 0x1a;

  return { shp: new Uint8Array(shp), shx: new Uint8Array(shx), dbf };
}
