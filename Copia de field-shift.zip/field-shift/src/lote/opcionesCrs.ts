/**
 * Coordinate systems for survey plans (DXF). Argentine cadastre and mensura plans use
 * POSGAR 2007 Gauss-Krüger (EPSG:5343–5349): one transverse-Mercator strip per 3° of
 * longitude, false easting = strip × 1,000,000 + 500,000. Santiago del Estero is strip 4.
 */
export type CrsId = `posgar2007-${1 | 2 | 3 | 4 | 5 | 6 | 7}` | `utm-${19 | 20 | 21}s` | 'wgs84';

export const CRS_POR_DEFECTO: CrsId = 'posgar2007-4';

export const OPCIONES_CRS: { id: CrsId; etiqueta: string; epsg: number }[] = [
  ...([1, 2, 3, 4, 5, 6, 7] as const).map((f) => ({
    id: `posgar2007-${f}` as CrsId,
    etiqueta: `POSGAR 2007 – faja ${f}${f === 4 ? ' (Santiago del Estero)' : ''}`,
    epsg: 5342 + f,
  })),
  ...([19, 20, 21] as const).map((z) => ({ id: `utm-${z}s` as CrsId, etiqueta: `WGS 84 / UTM ${z}S`, epsg: 32700 + z })),
  { id: 'wgs84', etiqueta: 'WGS 84 – latitud/longitud', epsg: 4326 },
];

