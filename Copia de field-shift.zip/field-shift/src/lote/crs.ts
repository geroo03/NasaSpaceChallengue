import proj4 from 'proj4';

import type { CrsId } from './opcionesCrs';

export type { CrsId } from './opcionesCrs';
export { CRS_POR_DEFECTO, OPCIONES_CRS } from './opcionesCrs';

function definicion(id: CrsId): string {
  if (id === 'wgs84') return '+proj=longlat +datum=WGS84 +no_defs';
  const posgar = /^posgar2007-(\d)$/.exec(id);
  if (posgar) {
    const faja = Number(posgar[1]);
    const lon0 = -72 + 3 * (faja - 1);
    const x0 = faja * 1_000_000 + 500_000;
    return `+proj=tmerc +lat_0=-90 +lon_0=${lon0} +k=1 +x_0=${x0} +y_0=0 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs`;
  }
  const utm = /^utm-(\d\d)s$/.exec(id);
  if (utm) return `+proj=utm +zone=${utm[1]} +south +datum=WGS84 +units=m +no_defs`;
  throw new Error(`Sistema de coordenadas desconocido: ${id}`);
}

/** Returns a function that converts [x, y] in `id` to [lon, lat] WGS84. */
export function conversorAWgs84(id: CrsId): (p: number[]) => [number, number] {
  if (id === 'wgs84') return (p) => [p[0] ?? NaN, p[1] ?? NaN];
  const conv = proj4(definicion(id), 'WGS84');
  return (p) => conv.forward([p[0] ?? NaN, p[1] ?? NaN]) as [number, number];
}

/**
 * The POSGAR false easting encodes the strip in its millions digit (4,5xx,xxx m → strip 4),
 * and a real easting sits within ~250 km of its strip's central meridian (x,500,000 m).
 * Returns the strip a value would belong to as an easting, or null if it cannot be one.
 */
export function fajaPorEste(este: number): number | null {
  const faja = Math.floor(este / 1_000_000);
  if (faja < 1 || faja > 7) return null;
  return Math.abs(este - (faja * 1_000_000 + 500_000)) <= 250_000 ? faja : null;
}

/** Northings of POSGAR Gauss-Krüger in Argentina (origin at the South Pole): ≈ 3.7 to 7.7 million m. */
function pareceNorte(v: number): boolean {
  return v >= 3_500_000 && v <= 7_800_000;
}

export interface DecisionEjes {
  /** true when the file has X = north, Y = east (common in Argentine survey plans). */
  invertir: boolean;
  /** Strip implied by the eastings, or null if it cannot be told. */
  fajaDetectada: number | null;
}

/**
 * Surveyors in Argentina often write Gauss-Krüger as X = north, Y = east, the reverse of
 * CAD's x = east. Decide from one sample vertex, preferring the strip the user chose.
 */
export function decidirEjes(x: number, y: number, fajaElegida: number): DecisionEjes {
  const fx = fajaPorEste(x);
  const fy = fajaPorEste(y);
  if (fx === fajaElegida && pareceNorte(y)) return { invertir: false, fajaDetectada: fx };
  if (fy === fajaElegida && pareceNorte(x)) return { invertir: true, fajaDetectada: fy };
  if (fx !== null && pareceNorte(y)) return { invertir: false, fajaDetectada: fx };
  if (fy !== null && pareceNorte(x)) return { invertir: true, fajaDetectada: fy };
  return { invertir: false, fajaDetectada: null };
}
