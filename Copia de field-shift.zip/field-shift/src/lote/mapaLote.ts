import L from 'leaflet';
import '@geoman-io/leaflet-geoman-free';
import '@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css';
import type { Polygon } from 'geojson';
import { medir, validar, type MotivoInvalido } from './geometria';
import { buscarPasadas, mejorPasada, urlTeselaHls, type PasadaHls } from './hls';

export type Procedencia =
  | { tipo: 'dibujo' }
  | { tipo: 'archivo'; archivo: string; parcela: string; editado: boolean };

export interface Lote {
  geometry: Polygon;
  areaHa: number;
  centroLat: number;
  centroLon: number;
  procedencia: Procedencia;
}

export interface EstadoLote {
  lote: Lote | null;
  /** Why the last drawn/edited polygon was rejected, if it was. */
  motivo: MotivoInvalido | null;
}

export interface TextosMapa {
  dibujar: string;
  editar: string;
  borrar: string;
  deshacer: string;
  terminar: string;
  cancelar: string;
  fondoEsri: string;
  fondoHls: string;
  fondoOsm: string;
}

const ESTILO_OK: L.PathOptions = { color: '#f4d35e', weight: 3, fillOpacity: 0.12 };
const ESTILO_ERROR: L.PathOptions = { color: '#d1495b', weight: 3, dashArray: '6 4', fillOpacity: 0.08 };

/**
 * Leaflet map with one editable field polygon (Geoman), Esri high-resolution and NASA HLS
 * backgrounds, and NASA GIBS overlays. Owns the map; reports the lot through `onCambio`.
 */
export class MapaLote {
  readonly map: L.Map;
  private capaLote: L.Polygon | null = null;
  private procedencia: Procedencia = { tipo: 'dibujo' };
  private readonly hls: L.TileLayer;
  private pasadas: PasadaHls[] = [];
  private controlCapas: L.Control.Layers | null = null;
  private readonly base: { esri: L.TileLayer; osm: L.TileLayer };
  private readonly overlays: Record<string, L.TileLayer>;

  constructor(
    contenedor: string,
    centro: [number, number],
    private readonly onCambio: (e: EstadoLote) => void,
    private readonly onPasadasHls: (pasadas: PasadaHls[], elegida: PasadaHls | null, error: boolean) => void,
  ) {
    this.map = L.map(contenedor).setView(centro, 13);

    this.base = {
      esri: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 19,
        attribution: 'Esri, Maxar, Earthstar Geographics',
      }),
      osm: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap',
      }),
    };
    this.hls = L.tileLayer('', { maxNativeZoom: 12, maxZoom: 19, attribution: 'NASA GIBS / HLS' });
    this.base.esri.addTo(this.map);

    const gibsDate = new Date(Date.now() - 20 * 86_400_000).toISOString().slice(0, 10);
    this.overlays = {
      ndvi: L.tileLayer(
        `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_L3_NDVI_16Day/default/${gibsDate}/GoogleMapsCompatible_Level9/{z}/{y}/{x}.png`,
        { maxNativeZoom: 9, maxZoom: 19, opacity: 0.7, attribution: 'NASA GIBS / MODIS' },
      ),
      smap: L.tileLayer(
        `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/SMAP_L4_Analyzed_Root_Zone_Soil_Moisture/default/${gibsDate}/GoogleMapsCompatible_Level6/{z}/{y}/{x}.png`,
        { maxNativeZoom: 6, maxZoom: 19, opacity: 0.6, attribution: 'NASA GIBS / SMAP L4' },
      ),
    };

    this.map.on('pm:create', (e: { layer: L.Layer }) => {
      this.capaLote?.remove();
      this.capaLote = e.layer as L.Polygon;
      this.procedencia = { tipo: 'dibujo' };
      this.engancharEdicion(this.capaLote);
      this.evaluar();
    });
    this.map.on('pm:remove', (e: { layer: L.Layer }) => {
      if (e.layer === this.capaLote) {
        this.capaLote = null;
        this.onCambio({ lote: null, motivo: null });
      }
    });
  }

  /** (Re)builds controls and texts; called on start and whenever the language changes. */
  aplicarTextos(t: TextosMapa, lang: 'es' | 'en'): void {
    this.map.pm.setLang(
      lang,
      {
        actions: { removeLastVertex: t.deshacer, finish: t.terminar, cancel: t.cancelar },
        buttonTitles: { drawPolyButton: t.dibujar, editButton: t.editar, deleteButton: t.borrar },
      },
      'en',
    );
    this.map.pm.removeControls();
    this.map.pm.addControls({
      position: 'topleft',
      drawPolygon: true,
      editMode: true,
      removalMode: true,
      drawMarker: false,
      drawCircleMarker: false,
      drawCircle: false,
      drawPolyline: false,
      drawRectangle: false,
      drawText: false,
      dragMode: false,
      cutPolygon: false,
      rotateMode: false,
    });
    // Close the ring by clicking the first vertex; no snapping to other layers.
    this.map.pm.setGlobalOptions({ snappable: false, finishOn: null, allowSelfIntersection: true });

    this.controlCapas?.remove();
    this.controlCapas = L.control
      .layers(
        { [t.fondoEsri]: this.base.esri, [t.fondoHls]: this.hls, [t.fondoOsm]: this.base.osm },
        { 'MODIS NDVI (NASA GIBS)': this.overlays['ndvi']!, 'SMAP L4 (NASA GIBS)': this.overlays['smap']! },
        { position: 'topright' },
      )
      .addTo(this.map);
  }

  /** Loads a polygon from a file as the current lot, editable, and zooms to it. */
  cargarPoligono(geometry: Polygon, procedencia: Procedencia): void {
    this.capaLote?.remove();
    const latlngs = (geometry.coordinates[0] ?? []).slice(0, -1).map(([lon, lat]) => L.latLng(lat ?? 0, lon ?? 0));
    this.capaLote = L.polygon(latlngs).addTo(this.map);
    this.procedencia = procedencia;
    this.engancharEdicion(this.capaLote);
    this.map.fitBounds(this.capaLote.getBounds(), { padding: [24, 24], maxZoom: 17 });
    this.evaluar();
  }

  centrarEn(lat: number, lon: number): void {
    this.map.setView([lat, lon], Math.max(this.map.getZoom(), 13));
  }

  elegirPasadaHls(p: PasadaHls): void {
    this.hls.setUrl(urlTeselaHls(p));
  }

  async actualizarHls(): Promise<void> {
    const b = this.capaLote ? this.capaLote.getBounds() : this.map.getBounds().pad(-0.4);
    const bbox: [number, number, number, number] = [b.getWest(), b.getSouth(), b.getEast(), b.getNorth()];
    try {
      this.pasadas = await buscarPasadas(bbox);
      const elegida = mejorPasada(this.pasadas);
      if (elegida) this.elegirPasadaHls(elegida);
      this.onPasadasHls(this.pasadas, elegida, false);
    } catch {
      this.onPasadasHls([], null, true);
    }
  }

  private engancharEdicion(capa: L.Polygon): void {
    const alEditar = () => {
      if (this.procedencia.tipo === 'archivo') this.procedencia = { ...this.procedencia, editado: true };
      this.evaluar();
    };
    capa.on('pm:edit', alEditar);
    capa.on('pm:markerdragend', alEditar);
    capa.on('pm:vertexremoved', alEditar);
  }

  private evaluar(): void {
    if (!this.capaLote) return;
    const gj = this.capaLote.toGeoJSON();
    if (gj.geometry.type !== 'Polygon') return;
    const geometry = gj.geometry as Polygon;
    const motivo = validar(geometry);
    this.capaLote.setStyle(motivo ? ESTILO_ERROR : ESTILO_OK);
    if (motivo) {
      this.onCambio({ lote: null, motivo });
      return;
    }
    const m = medir(geometry);
    this.onCambio({ lote: { geometry, ...m, procedencia: this.procedencia }, motivo: null });
  }
}
