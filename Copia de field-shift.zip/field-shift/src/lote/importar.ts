import { kml } from '@tmcw/togeojson';
import DxfParser from 'dxf-parser';
import JSZip from 'jszip';
import shp from 'shpjs';
import type { Feature, FeatureCollection, Geometry, Polygon } from 'geojson';
import { aCandidatos, pareceLonLat, type Candidato } from './geometria';
import { conversorAWgs84, decidirEjes, type CrsId } from './crs';

/**
 * Reads survey documentation entirely in the browser: nothing is uploaded anywhere.
 * Santiago del Estero publishes no cadastre web service (AgroCordS documents the same
 * finding), so files are the way in.
 */

export type Formato = 'kml' | 'kmz' | 'shp' | 'geojson' | 'dxf' | 'guia';

export type ResultadoImportacion =
  | { tipo: 'parcelas'; formato: Exclude<Formato, 'guia'>; archivo: string; candidatos: Candidato[]; avisos: Aviso[] }
  | { tipo: 'guia'; archivo: string; mime: string; url: string };

/** Translatable notice: the UI owns the wording. */
export interface Aviso {
  clave: string;
  params?: Record<string, string | number>;
}

export class ErrorImportacion extends Error {
  constructor(readonly clave: string, readonly params: Record<string, string | number> = {}) {
    super(clave);
    this.name = 'ErrorImportacion';
  }
}

export interface OpcionesImportacion {
  /** Coordinate system for DXF plans (plans carry no CRS of their own). */
  crsDxf: CrsId;
  /** Injected so tests can run without a browser. */
  crearUrl?: (blob: Blob) => string;
}

const MAX_BYTES = 30 * 1024 * 1024;

export function detectarFormato(nombre: string): Formato | null {
  const ext = nombre.toLowerCase().split('.').pop() ?? '';
  if (ext === 'kml') return 'kml';
  if (ext === 'kmz') return 'kmz';
  if (ext === 'zip') return 'shp';
  if (ext === 'geojson' || ext === 'json') return 'geojson';
  if (ext === 'dxf') return 'dxf';
  if (['pdf', 'jpg', 'jpeg', 'png', 'webp'].includes(ext)) return 'guia';
  return null;
}

export async function importarArchivo(archivo: File, opciones: OpcionesImportacion): Promise<ResultadoImportacion> {
  if (archivo.size > MAX_BYTES) throw new ErrorImportacion('import.error.grande', { mb: 30 });
  const formato = detectarFormato(archivo.name);
  if (!formato) throw new ErrorImportacion('import.error.formato', { archivo: archivo.name });

  if (formato === 'guia') {
    const crear = opciones.crearUrl ?? ((b: Blob) => URL.createObjectURL(b));
    return { tipo: 'guia', archivo: archivo.name, mime: archivo.type || 'application/octet-stream', url: crear(archivo) };
  }

  const avisos: Aviso[] = [];
  let features: Feature<Geometry | null>[];
  try {
    switch (formato) {
      case 'kml':
        features = desdeKml(await leerTexto(archivo));
        break;
      case 'kmz':
        features = await desdeKmz(await leerBuffer(archivo));
        break;
      case 'shp':
        features = await desdeShapefile(await leerBuffer(archivo));
        break;
      case 'geojson':
        features = desdeGeojson(await leerTexto(archivo));
        break;
      case 'dxf':
        features = desdeDxf(await leerTexto(archivo), opciones.crsDxf, avisos);
        break;
    }
  } catch (err) {
    if (err instanceof ErrorImportacion) throw err;
    throw new ErrorImportacion('import.error.lectura', { archivo: archivo.name });
  }

  const candidatos = aCandidatos(features, formato);
  if (candidatos.length === 0) throw new ErrorImportacion('import.error.sinPoligonos', { archivo: archivo.name });
  for (const c of candidatos) {
    if (!pareceLonLat(c.geometry)) throw new ErrorImportacion('import.error.noLonLat', { archivo: archivo.name });
  }
  return { tipo: 'parcelas', formato, archivo: archivo.name, candidatos, avisos };
}

// ---------------------------------------------------------------------------

/** Blob.text()/arrayBuffer() with a FileReader fallback (older browsers, jsdom). */
function leerTexto(f: Blob): Promise<string> {
  if (typeof f.text === 'function') return f.text();
  return leerCon(f, 'texto') as Promise<string>;
}
function leerBuffer(f: Blob): Promise<ArrayBuffer> {
  if (typeof f.arrayBuffer === 'function') return f.arrayBuffer();
  return leerCon(f, 'buffer') as Promise<ArrayBuffer>;
}
function leerCon(f: Blob, modo: 'texto' | 'buffer'): Promise<string | ArrayBuffer> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string | ArrayBuffer);
    r.onerror = () => reject(r.error);
    if (modo === 'texto') r.readAsText(f);
    else r.readAsArrayBuffer(f);
  });
}

function desdeKml(texto: string): Feature<Geometry | null>[] {
  const doc = new DOMParser().parseFromString(texto, 'text/xml');
  if (doc.getElementsByTagName('parsererror').length) throw new ErrorImportacion('import.error.lectura', { archivo: 'KML' });
  return kml(doc).features as Feature<Geometry | null>[];
}

async function desdeKmz(buffer: ArrayBuffer): Promise<Feature<Geometry | null>[]> {
  const zip = await JSZip.loadAsync(buffer);
  // By convention the main document is doc.kml; otherwise take the first .kml in the archive.
  const entrada = zip.file('doc.kml') ?? zip.file(/\.kml$/i)[0];
  if (!entrada) throw new ErrorImportacion('import.error.kmzSinKml');
  return desdeKml(await entrada.async('string'));
}

async function desdeShapefile(buffer: ArrayBuffer): Promise<Feature<Geometry | null>[]> {
  const zip = await JSZip.loadAsync(buffer);
  if (zip.file(/\.shp$/i).length === 0) throw new ErrorImportacion('import.error.zipSinShp');
  if (zip.file(/\.prj$/i).length === 0) throw new ErrorImportacion('import.error.shpSinPrj');
  // shpjs reprojects to WGS84 using the .prj it finds next to the .shp.
  const r = (await shp(buffer)) as FeatureCollection | FeatureCollection[];
  const colecciones = Array.isArray(r) ? r : [r];
  return colecciones.flatMap((c) => c.features as Feature<Geometry | null>[]);
}

function desdeGeojson(texto: string): Feature<Geometry | null>[] {
  const json: unknown = JSON.parse(texto);
  if (!json || typeof json !== 'object' || !('type' in json)) throw new ErrorImportacion('import.error.lectura', { archivo: 'GeoJSON' });
  const obj = json as { type: string };
  if (obj.type === 'FeatureCollection') return (json as FeatureCollection).features as Feature<Geometry | null>[];
  if (obj.type === 'Feature') return [json as Feature<Geometry | null>];
  return [{ type: 'Feature', properties: {}, geometry: json as Geometry }];
}

function desdeDxf(texto: string, crs: CrsId, avisos: Aviso[]): Feature<Geometry | null>[] {
  const dxf = new DxfParser().parseSync(texto);
  const polilineas = (dxf?.entities ?? []).filter(
    (e): e is typeof e & { vertices: { x: number; y: number }[]; shape?: boolean } =>
      (e.type === 'LWPOLYLINE' || e.type === 'POLYLINE') && Array.isArray((e as { vertices?: unknown }).vertices),
  );
  const cerradas = polilineas.filter((e) => {
    const v = e.vertices;
    if (v.length < 3) return false;
    const a = v[0]!;
    const z = v[v.length - 1]!;
    return e.shape === true || (a.x === z.x && a.y === z.y);
  });
  if (cerradas.length === 0) throw new ErrorImportacion('import.error.dxfSinPolilineas');

  let crsUsado = crs;
  let invertir = false;
  const posgar = /^posgar2007-(\d)$/.exec(crs);
  const muestra = cerradas[0]!.vertices[0]!;
  if (posgar) {
    const decision = decidirEjes(muestra.x, muestra.y, Number(posgar[1]));
    invertir = decision.invertir;
    if (invertir) avisos.push({ clave: 'import.aviso.ejesInvertidos' });
    if (decision.fajaDetectada !== null && decision.fajaDetectada !== Number(posgar[1])) {
      crsUsado = `posgar2007-${decision.fajaDetectada}` as CrsId;
      avisos.push({ clave: 'import.aviso.fajaCorregida', params: { elegida: Number(posgar[1]), detectada: decision.fajaDetectada } });
    }
  } else if (crs !== 'wgs84' && Math.abs(muestra.x) <= 180 && Math.abs(muestra.y) <= 90) {
    // Numbers this small are degrees, not metres: the plan is already in lat/lon.
    crsUsado = 'wgs84';
    avisos.push({ clave: 'import.aviso.pareceLonLat' });
  }
  avisos.push({ clave: 'import.aviso.crsUsado', params: { crs: crsUsado } });

  const aWgs = conversorAWgs84(crsUsado);
  return cerradas.map((e, i) => {
    const ring = e.vertices.map((v) => aWgs(invertir ? [v.y, v.x] : [v.x, v.y]));
    const geometry: Polygon = { type: 'Polygon', coordinates: [ring] };
    const layer = (e as { layer?: string }).layer;
    return { type: 'Feature', properties: { name: layer && layer !== '0' ? `${layer} ${i + 1}` : `Polilínea ${i + 1}` }, geometry };
  });
}
