/**
 * NASA HLS (Harmonized Landsat Sentinel-2, 30 m) as a map background.
 *
 * GIBS publishes HLS as DAILY tiles: on most days there is no pass over a given field, so
 * picking "today" shows nothing. We ask NASA CMR-STAC which passes actually covered the
 * field, and how cloudy they were, and show the most recent clear one.
 * Both endpoints are public, keyless and CORS-enabled (checked from a browser).
 */

const STAC_SEARCH = 'https://cmr.earthdata.nasa.gov/stac/LPCLOUD/search';

export type Sensor = 'S30' | 'L30';

export interface PasadaHls {
  /** YYYY-MM-DD (UTC), the date GIBS uses for the tile */
  fecha: string;
  sensor: Sensor;
  nubesPct: number | null;
}

export function capaGibs(sensor: Sensor): string {
  return `HLS_${sensor}_Nadir_BRDF_Adjusted_Reflectance`;
}

export function urlTeselaHls(p: PasadaHls): string {
  return `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/${capaGibs(p.sensor)}/default/${p.fecha}/GoogleMapsCompatible_Level12/{z}/{y}/{x}.png`;
}

/** Parses a STAC ItemCollection into passes, newest first, one per date and sensor. */
export function parsearPasadas(json: unknown): PasadaHls[] {
  const features = (json as { features?: unknown })?.features;
  if (!Array.isArray(features)) return [];
  const vistos = new Set<string>();
  const out: PasadaHls[] = [];
  for (const f of features as { collection?: string; properties?: Record<string, unknown> }[]) {
    const dt = f.properties?.['datetime'];
    if (typeof dt !== 'string') continue;
    const sensor: Sensor | null = f.collection?.startsWith('HLSS30') ? 'S30' : f.collection?.startsWith('HLSL30') ? 'L30' : null;
    if (!sensor) continue;
    const fecha = dt.slice(0, 10);
    const clave = `${fecha}-${sensor}`;
    if (vistos.has(clave)) continue;
    vistos.add(clave);
    const nubes = f.properties?.['eo:cloud_cover'];
    out.push({ fecha, sensor, nubesPct: typeof nubes === 'number' ? nubes : null });
  }
  return out.sort((a, b) => b.fecha.localeCompare(a.fecha));
}

/** The most recent pass under the cloud threshold, or the least cloudy one if none is. */
export function mejorPasada(pasadas: PasadaHls[], maxNubes = 20): PasadaHls | null {
  const limpia = pasadas.find((p) => p.nubesPct !== null && p.nubesPct <= maxNubes);
  if (limpia) return limpia;
  return [...pasadas].sort((a, b) => (a.nubesPct ?? 101) - (b.nubesPct ?? 101))[0] ?? null;
}

export async function buscarPasadas(
  bbox: [number, number, number, number],
  dias = 120,
  fetchImpl: typeof fetch = fetch,
  hoy: Date = new Date(),
): Promise<PasadaHls[]> {
  const desde = new Date(hoy.getTime() - dias * 86_400_000).toISOString().slice(0, 10);
  const hasta = hoy.toISOString().slice(0, 10);
  const r = await fetchImpl(STAC_SEARCH, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      collections: ['HLSS30_2.0', 'HLSL30_2.0'],
      bbox,
      datetime: `${desde}T00:00:00Z/${hasta}T23:59:59Z`,
      limit: 100,
    }),
  });
  if (!r.ok) throw new Error(`NASA CMR-STAC respondió HTTP ${r.status}`);
  return parsearPasadas(await r.json());
}
