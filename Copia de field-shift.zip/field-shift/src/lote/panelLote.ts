import type { Lang } from '../i18n';
import { t } from '../i18n';
import { CRS_POR_DEFECTO, OPCIONES_CRS, type CrsId } from './opcionesCrs';
import type { Candidato } from './geometria';
import type { ResultadoImportacion } from './importar';
import { MapaLote, type EstadoLote, type Lote, type Procedencia } from './mapaLote';
import type { PasadaHls } from './hls';

/**
 * UI glue for the field: map + drawing, NASA HLS background picker and the survey-file
 * importer. Keeps main.ts free of lot details; exposes the current lot.
 */
export interface PanelLote {
  lote(): Lote | null;
  aplicarIdioma(lang: Lang): void;
}

const $ = <T extends HTMLElement>(id: string): T => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`#${id} not found`);
  return el as T;
};

export function iniciarPanelLote(centro: [number, number], onLote: (lote: Lote | null) => void): PanelLote {
  let lang: Lang = 'es';
  let estado: EstadoLote = { lote: null, motivo: null };
  let pasadas: PasadaHls[] = [];
  let pasadaElegida: PasadaHls | null = null;
  let hlsError = false;
  let hlsBuscando = false;
  let ultimoResultado: ResultadoImportacion | null = null;
  let urlGuia: string | null = null;
  let estadoImport: { clave: string; params?: Record<string, string | number>; error?: boolean } | null = null;

  const estadoEl = $<HTMLDivElement>('lote-estado');
  const hlsSelect = $<HTMLSelectElement>('hls-pasada');
  const hlsEstado = $<HTMLParagraphElement>('hls-estado');
  const archivoInput = $<HTMLInputElement>('import-archivo');
  const crsSelect = $<HTMLSelectElement>('import-crs');
  const importEstado = $<HTMLParagraphElement>('import-estado');
  const candidatosEl = $<HTMLDivElement>('import-candidatos');
  const guiaEl = $<HTMLDivElement>('import-guia');
  const wrap = $<HTMLDivElement>('map-wrap');
  const toggle = $<HTMLButtonElement>('map-toggle');

  crsSelect.replaceChildren(...OPCIONES_CRS.map((o) => new Option(o.etiqueta, o.id, false, o.id === CRS_POR_DEFECTO)));

  const mapa = new MapaLote(
    'map',
    centro,
    (e) => {
      estado = e;
      pintarEstado();
      onLote(e.lote);
      if (e.lote) void buscarHls();
    },
    (ps, elegida, error) => {
      pasadas = ps;
      pasadaElegida = elegida;
      hlsError = error;
      hlsBuscando = false;
      pintarHls();
    },
  );

  async function buscarHls() {
    hlsBuscando = true;
    pintarHls();
    await mapa.actualizarHls();
  }

  // ---- map size ------------------------------------------------------------
  toggle.addEventListener('click', () => {
    wrap.classList.toggle('grande');
    toggle.textContent = t(lang, wrap.classList.contains('grande') ? 'lote.cerrarMapa' : 'lote.ampliar');
    setTimeout(() => mapa.map.invalidateSize(), 50);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && wrap.classList.contains('grande')) toggle.click();
  });

  // ---- HLS background --------------------------------------------------------
  hlsSelect.addEventListener('change', () => {
    const p = pasadas[Number(hlsSelect.value)];
    if (p) {
      pasadaElegida = p;
      mapa.elegirPasadaHls(p);
    }
  });

  function pintarHls() {
    hlsSelect.replaceChildren(
      ...pasadas.map(
        (p, i) =>
          new Option(
            t(lang, 'hls.opcion', {
              fecha: p.fecha,
              sensor: t(lang, p.sensor === 'S30' ? 'hls.s30' : 'hls.l30'),
              nubes: p.nubesPct === null ? '?' : Math.round(p.nubesPct),
            }),
            String(i),
            false,
            p === pasadaElegida,
          ),
      ),
    );
    hlsSelect.disabled = pasadas.length === 0;
    hlsEstado.textContent = hlsBuscando
      ? t(lang, 'hls.buscando')
      : hlsError
        ? t(lang, 'hls.error')
        : pasadas.length === 0
          ? t(lang, 'hls.ninguna')
          : t(lang, 'hls.elegida');
  }

  // ---- lot status ----------------------------------------------------------
  function textoProcedencia(p: Procedencia): string {
    if (p.tipo === 'dibujo') return t(lang, 'lote.proc.dibujo');
    return t(lang, 'lote.proc.archivo', { archivo: p.archivo, parcela: p.parcela }) + (p.editado ? t(lang, 'lote.proc.editado') : '');
  }

  function pintarEstado() {
    estadoEl.classList.toggle('error', estado.motivo !== null);
    estadoEl.replaceChildren();
    if (estado.lote) {
      const fuerte = document.createElement('strong');
      fuerte.textContent = t(lang, 'lote.ok', { ha: estado.lote.areaHa.toLocaleString(lang, { maximumFractionDigits: 2 }) });
      estadoEl.append(fuerte, document.createElement('br'), textoProcedencia(estado.lote.procedencia));
    } else if (estado.motivo) {
      estadoEl.textContent = t(lang, `lote.motivo.${estado.motivo}`);
    } else {
      estadoEl.textContent = t(lang, 'lote.sinLote');
    }
  }

  // ---- importer -----------------------------------------------------------
  archivoInput.addEventListener('change', () => {
    const archivo = archivoInput.files?.[0];
    if (archivo) void importar(archivo);
  });
  crsSelect.addEventListener('change', () => {
    // A DXF has no CRS of its own: re-read it with the new choice.
    const archivo = archivoInput.files?.[0];
    if (archivo && archivo.name.toLowerCase().endsWith('.dxf')) void importar(archivo);
  });

  async function importar(archivo: File) {
    estadoImport = { clave: 'import.leyendo', params: { archivo: archivo.name } };
    ultimoResultado = null;
    pintarImport();
    // Loaded on demand: proj4, shapefile and DXF parsers are only needed when a file is chosen.
    const { importarArchivo, ErrorImportacion } = await import('./importar');
    try {
      const r = await importarArchivo(archivo, { crsDxf: crsSelect.value as CrsId });
      if (urlGuia) URL.revokeObjectURL(urlGuia);
      urlGuia = r.tipo === 'guia' ? r.url : null;
      ultimoResultado = r;
      if (r.tipo === 'guia') estadoImport = { clave: 'import.guia' };
      else {
        const usables = r.candidatos.filter((c) => !c.motivo);
        estadoImport = r.candidatos.length === 1 ? { clave: 'import.una' } : { clave: 'import.elegir', params: { n: r.candidatos.length } };
        // A single valid parcel is loaded straight away; with several the farmer chooses.
        if (r.candidatos.length === 1 && usables.length === 1) usar(r.archivo, usables[0]!);
      }
    } catch (err) {
      estadoImport =
        err instanceof ErrorImportacion
          ? { clave: err.clave, params: err.params, error: true }
          : { clave: 'import.error.lectura', params: { archivo: archivo.name }, error: true };
    }
    pintarImport();
  }

  function usar(archivo: string, c: Candidato) {
    mapa.cargarPoligono(c.geometry, { tipo: 'archivo', archivo, parcela: c.nombre, editado: false });
  }

  function pintarImport() {
    importEstado.classList.toggle('error', Boolean(estadoImport?.error));
    const lineas: string[] = estadoImport ? [t(lang, estadoImport.clave, estadoImport.params ?? {})] : [];
    if (ultimoResultado?.tipo === 'parcelas') {
      for (const a of ultimoResultado.avisos) lineas.push(t(lang, a.clave, a.params ?? {}));
    }
    importEstado.textContent = lineas.join(' ');

    candidatosEl.replaceChildren();
    guiaEl.replaceChildren();
    guiaEl.hidden = true;
    if (!ultimoResultado) return;

    if (ultimoResultado.tipo === 'guia') {
      guiaEl.hidden = false;
      const esPdf = ultimoResultado.mime === 'application/pdf' || ultimoResultado.archivo.toLowerCase().endsWith('.pdf');
      const vista = esPdf ? document.createElement('iframe') : document.createElement('img');
      vista.setAttribute('src', ultimoResultado.url);
      vista.setAttribute(esPdf ? 'title' : 'alt', ultimoResultado.archivo);
      guiaEl.append(vista);
      return;
    }

    const r = ultimoResultado;
    for (const c of r.candidatos) {
      const fila = document.createElement('label');
      fila.className = `candidato${c.motivo ? ' bloqueado' : ''}`;
      const radio = document.createElement('input');
      radio.type = 'radio';
      radio.name = 'candidato';
      radio.disabled = c.motivo !== null;
      radio.addEventListener('change', () => usar(r.archivo, c));
      const texto = document.createElement('span');
      const nombre = document.createElement('strong');
      nombre.textContent = c.nombre;
      texto.append(nombre, ` · ${c.areaHa > 0 ? t(lang, 'import.ha', { ha: c.areaHa.toLocaleString(lang, { maximumFractionDigits: 2 }) }) : '—'}`);
      if (c.motivo) {
        const motivo = document.createElement('span');
        motivo.className = 'motivo';
        motivo.textContent = t(lang, `lote.motivo.${c.motivo}`);
        texto.append(motivo);
      }
      fila.append(radio, texto);
      candidatosEl.append(fila);
    }
  }

  function aplicarIdioma(l: Lang) {
    lang = l;
    mapa.aplicarTextos(
      {
        dibujar: t(lang, 'mapa.dibujar'),
        editar: t(lang, 'mapa.editar'),
        borrar: t(lang, 'mapa.borrar'),
        deshacer: t(lang, 'mapa.deshacer'),
        terminar: t(lang, 'mapa.terminar'),
        cancelar: t(lang, 'mapa.cancelar'),
        fondoEsri: t(lang, 'mapa.fondoEsri'),
        fondoHls: t(lang, 'mapa.fondoHls'),
        fondoOsm: t(lang, 'mapa.fondoOsm'),
      },
      lang,
    );
    toggle.textContent = t(lang, wrap.classList.contains('grande') ? 'lote.cerrarMapa' : 'lote.ampliar');
    pintarEstado();
    pintarHls();
    pintarImport();
  }

  aplicarIdioma(lang);
  void buscarHls();

  return { lote: () => estado.lote, aplicarIdioma };
}
