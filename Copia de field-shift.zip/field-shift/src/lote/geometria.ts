import area from '@turf/area';
import centroid from '@turf/centroid';
import kinks from '@turf/kinks';
import type { Feature, Geometry, Polygon, Position } from 'geojson';

/**
 * Lot geometry rules. Same thresholds AgroCordS uses for its lot drawing:
 * below 0.5 ha it is almost always a misclick; above 5,000 ha someone drew the
 * whole farm instead of one field.
 */
export const AREA_MINIMA_HA = 0.5;
export const AREA_MAXIMA_HA = 5000;

export type MotivoInvalido = 'pocosVertices' | 'seCruza' | 'muyChico' | 'muyGrande' | 'variasPartes' | 'sinArea';

export interface Medidas {
  areaHa: number;
  centroLat: number;
  centroLon: number;
}

export interface Candidato {
  id: string;
  nombre: string;
  geometry: Polygon;
  areaHa: number;
  /** null when the polygon is usable as a lot */
  motivo: MotivoInvalido | null;
}

export function medir(geometry: Polygon): Medidas {
  const f: Feature<Polygon> = { type: 'Feature', properties: {}, geometry };
  const [lon, lat] = centroid(f).geometry.coordinates as [number, number];
  return { areaHa: Math.round((area(f) / 10_000) * 100) / 100, centroLat: lat, centroLon: lon };
}

export function validar(geometry: Polygon): MotivoInvalido | null {
  const anillo = geometry.coordinates[0] ?? [];
  // A GeoJSON ring repeats the first vertex at the end: a triangle has 4 positions.
  if (anillo.length < 4) return 'pocosVertices';
  // A self-intersecting polygon has no meaningful area, so this goes before size.
  if (kinks({ type: 'Feature', properties: {}, geometry }).features.length > 0) return 'seCruza';
  const { areaHa } = medir(geometry);
  if (areaHa <= 0) return 'sinArea';
  if (areaHa < AREA_MINIMA_HA) return 'muyChico';
  if (areaHa > AREA_MAXIMA_HA) return 'muyGrande';
  return null;
}

/** Drops altitude (KML often carries it) and makes sure the ring is closed. */
export function limpiarAnillo(anillo: Position[]): Position[] {
  const plano = anillo.map((p) => [p[0] ?? NaN, p[1] ?? NaN]).filter((p) => Number.isFinite(p[0]) && Number.isFinite(p[1]));
  if (plano.length === 0) return plano;
  const [a, z] = [plano[0]!, plano[plano.length - 1]!];
  if (a[0] !== z[0] || a[1] !== z[1]) plano.push([a[0]!, a[1]!]);
  return plano;
}

const CLAVES_NOMBRE = ['name', 'Name', 'NAME', 'nombre', 'Nombre', 'NOMBRE', 'nomenclatura', 'NOMENCLATU', 'parcela', 'PARCELA', 'partida', 'PARTIDA', 'lote', 'LOTE', 'id', 'ID'];

function nombreDe(props: Record<string, unknown> | null | undefined, fallback: string): string {
  if (props) {
    for (const k of CLAVES_NOMBRE) {
      const v = props[k];
      if ((typeof v === 'string' && v.trim()) || typeof v === 'number') return String(v).trim();
    }
  }
  return fallback;
}

/**
 * Turns whatever a file contained into candidate lots. Polygons pass through; a closed
 * line (common in cadastre exports) becomes a polygon; a multipolygon with several parts
 * is offered but blocked, because a lot is one piece of land.
 */
export function aCandidatos(features: Feature<Geometry | null>[], prefijo: string): Candidato[] {
  const out: Candidato[] = [];
  let n = 0;
  for (const f of features) {
    const g = f.geometry;
    if (!g) continue;
    const props = (f.properties ?? null) as Record<string, unknown> | null;
    const agregar = (anillo: Position[], motivoForzado: MotivoInvalido | null = null, sufijo = '') => {
      n += 1;
      const ring = limpiarAnillo(anillo);
      const geometry: Polygon = { type: 'Polygon', coordinates: [ring] };
      const motivo = motivoForzado ?? validar(geometry);
      const areaHa = ring.length >= 4 && motivo !== 'seCruza' ? medir(geometry).areaHa : 0;
      out.push({ id: `${prefijo}-${n}`, nombre: nombreDe(props, `Parcela ${n}`) + sufijo, geometry, areaHa, motivo });
    };
    switch (g.type) {
      case 'Polygon':
        if (g.coordinates[0]) agregar(g.coordinates[0]);
        break;
      case 'MultiPolygon':
        if (g.coordinates.length === 1 && g.coordinates[0]?.[0]) agregar(g.coordinates[0][0]);
        else g.coordinates.forEach((p, i) => p[0] && agregar(p[0], 'variasPartes', ` (parte ${i + 1})`));
        break;
      case 'LineString': {
        const c = g.coordinates;
        const cerrada = c.length >= 4 && c[0]?.[0] === c[c.length - 1]?.[0] && c[0]?.[1] === c[c.length - 1]?.[1];
        if (cerrada) agregar(c);
        break;
      }
      case 'GeometryCollection':
        out.push(...aCandidatos(g.geometries.map((geometry) => ({ type: 'Feature', properties: props, geometry })), `${prefijo}-gc${n}`));
        break;
      default:
        break; // points and open lines are not lots
    }
  }
  return out;
}

/** True when every coordinate is a plausible longitude/latitude pair. */
export function pareceLonLat(geometry: Polygon): boolean {
  return geometry.coordinates.every((ring) => ring.every(([x, y]) => Math.abs(x ?? 999) <= 180 && Math.abs(y ?? 999) <= 90));
}
